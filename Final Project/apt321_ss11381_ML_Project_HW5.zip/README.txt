File Contents
1. Source Code: apt321_ss11381_ML_Final_Project_HW5.ipynb (Executable Jupyter Notebook) 

2. Test Output: test_outputs.csv (Submission File)

3. Project Report: apt321_ss11381_ML_Project_HW5_Report.pdf

4. Visualizations from Exploratory Analysis: /Visualizations/* (Visualizations content present in notebook in markdown language format)

Execution Instructions:
Open the Jupyer notebook `apt321_ss11381_ML_Final_Project_HW5.ipynb`. Run all the cells, in the end the predicted output will be generated.
 You will need numpy, pandas, sci-kit learn, math and matplotlib libraries.



