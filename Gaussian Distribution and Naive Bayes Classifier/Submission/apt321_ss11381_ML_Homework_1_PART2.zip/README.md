# Machine Learning - Assignment 1
## Submission by - Akshay Tambe (apt321) & Snahil Singh (ss11381)

Submission Files:  
PART 1: Theory Problems
- apt321_ss11381_ML_Homework_1_PART1.pdf

PART 2: Programming (Zipped File - apt321_ss11381_ML_Homework_1_PART2.zip)
- apt321_ss11381_ML_Homework_1.ipynb (Python Notebook File)
- apt321_ss11381_ML_Homework_1.py (Python Executable Script)
- proganswers.pdf (Programming Answers)

If any problems with the file, please check for Github Submission (No Modifications done after Due Date)
